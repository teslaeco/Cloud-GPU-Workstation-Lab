# Cloud GPU Workstation Lab

**Open-source practical guides for on-demand GPU workstations used in game development, AI, 3D, CAD, rendering, simulation, and scientific computing.**

[Polska wersja](README.pl.md)

> Rent powerful hardware only when it is needed. Stop it after work. Keep source code, backups, security, and costs under control.

## Why this repository exists

Independent developers and small teams do not always need to purchase a high-end workstation or an eight-GPU server. A cloud workstation can be started for focused work in Unreal Engine, while a separate GPU cluster can be rented only for model training, rendering, simulation, or batch processing.

This repository is based on practical experience with:

- an 8× NVIDIA H100 environment used during OpenAI Parameter Golf,
- a Google Cloud Windows workstation with an NVIDIA L4 GPU,
- remote development from an Android device,
- Unreal Engine, AI tooling, 3D workflows, and Git-based project management.

The goal is not to claim that one provider is best for every task. The goal is to help people select the right machine, prepare the workload before renting it, and avoid paying for idle compute.

## Who can benefit

- game developers using Unreal Engine or other GPU-heavy tools,
- AI engineers training or evaluating models,
- 3D artists, animators, and VFX teams,
- architects and CAD/BIM users,
- researchers and scientific-computing teams,
- geospatial, remote-sensing, and digital-twin projects,
- video creators and render farms,
- students and independent creators without expensive local hardware.

## Two-machine strategy

| Workload | Recommended class | Example |
|---|---|---|
| Interactive editor, game development, 3D work | GPU virtual workstation | Windows + NVIDIA L4 |
| Large model training, self-play, batch simulation | Linux GPU node or cluster | 1–8× H100 |
| Documentation, Git, issue tracking | Low-cost CPU machine or local device | GitHub + browser |

A large H100 cluster does not make normal desktop work eight times faster. It is valuable when the workload can be parallelized across GPUs.

## Repository map

- [`docs/01-architecture.md`](docs/01-architecture.md) — choose the correct architecture
- [`docs/02-google-cloud-l4-windows.md`](docs/02-google-cloud-l4-windows.md) — Windows + NVIDIA L4 workstation
- [`docs/03-runpod-h100-training.md`](docs/03-runpod-h100-training.md) — H100 training and batch workloads
- [`docs/04-cost-control.md`](docs/04-cost-control.md) — shutdown, storage, budgets, and break-even
- [`docs/05-security.md`](docs/05-security.md) — RDP, firewall, secrets, and backups
- [`docs/06-industry-use-cases.md`](docs/06-industry-use-cases.md) — applications beyond games
- [`docs/07-affiliate-and-ethics.md`](docs/07-affiliate-and-ethics.md) — transparent referral monetization
- [`docs/08-troubleshooting.md`](docs/08-troubleshooting.md) — common failures
- [`docs/09-case-study.md`](docs/09-case-study.md) — learning path from 8× H100 to L4
- [`tools/cost_estimator.py`](tools/cost_estimator.py) — rental-versus-purchase calculator
- [`scripts/windows`](scripts/windows) — PowerShell setup scripts
- [`scripts/linux`](scripts/linux) — Linux GPU verification

## Quick start

### Estimate rental versus purchase

```bash
python tools/cost_estimator.py   --purchase-cost 55000   --hourly-rate 10   --hours 100   --storage-monthly 150   --months 1
```

### Install development tools on Windows

Run PowerShell as Administrator:

```powershell
Set-ExecutionPolicy Bypass -Scope Process -Force
.\scripts\windows\install-dev-tools.ps1
.\scripts\windows\verify-workstation.ps1
```

### Stop the VM after work

In Google Cloud Console:

**Compute Engine → VM instances → select the VM → Stop**

Wait until the state is **TERMINATED**. Compute usage stops, but persistent disks and some reserved resources can still generate charges.

## Cost principles

1. Closing Remote Desktop does not stop a VM.
2. A budget alert is usually not a hard spending cap.
3. Stopping and deleting are different operations.
4. Persistent storage, snapshots, static IP addresses, and network traffic can still cost money.
5. Long jobs need checkpoints.
6. Compare the complete task cost, not only the advertised GPU hourly rate.

## Safety and accuracy

Cloud products, quotas, driver versions, prices, and affiliate rules change. This repository does not present temporary prices as permanent facts. Verify current provider documentation before creating resources.

## Affiliate disclosure

Any referral link must be clearly labelled. A referral relationship must not change the technical recommendation or hide costs, limitations, risks, or alternatives. See [`docs/07-affiliate-and-ethics.md`](docs/07-affiliate-and-ethics.md).

## Contributing

Read [`CONTRIBUTING.md`](CONTRIBUTING.md). Every material change should explain its purpose, risks, compatibility, tests, and documentation impact.

## License

Apache License 2.0. See [`LICENSE`](LICENSE).
