# Contributing

## Principles

- Prefer provider-neutral architecture where practical.
- Do not publish credentials, personal data, billing identifiers, or private access details.
- Do not present changing prices as permanent facts.
- Use primary official documentation for technical claims.
- Keep scripts repeatable and fail with useful messages.
- Maintain backward compatibility unless a pull request justifies a breaking change.

## Pull request workflow

1. Open an issue for a material change.
2. Create one focused branch.
3. Add or update tests.
4. Update documentation.
5. Run local checks.
6. Open one pull request for one logical change.
7. Explain purpose, risk, compatibility, and verification.
8. Merge only after CI is green.

## Local checks

```bash
python -m pip install -e ".[dev]"
ruff check .
pytest
```
