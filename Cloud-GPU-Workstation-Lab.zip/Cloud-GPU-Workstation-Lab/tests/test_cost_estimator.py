import pytest

from tools.cost_estimator import (
    CostScenario,
    break_even_hours,
    effective_purchase_cost,
    rental_cost,
)


def test_rental_cost_includes_runtime_and_storage() -> None:
    scenario = CostScenario(
        purchase_cost=55_000,
        hourly_rate=10,
        hours=100,
        storage_monthly=150,
        months=1,
    )
    assert rental_cost(scenario) == pytest.approx(1_150)


def test_effective_purchase_cost() -> None:
    scenario = CostScenario(
        purchase_cost=55_000,
        hourly_rate=10,
        hours=100,
        residual_value=15_000,
        maintenance_total=5_000,
    )
    assert effective_purchase_cost(scenario) == pytest.approx(45_000)


def test_break_even_hours() -> None:
    scenario = CostScenario(
        purchase_cost=55_000,
        hourly_rate=10,
        hours=100,
        storage_monthly=150,
        months=1,
    )
    assert break_even_hours(scenario) == pytest.approx(5_485)


def test_zero_hourly_rate_has_no_break_even() -> None:
    scenario = CostScenario(purchase_cost=55_000, hourly_rate=0, hours=100)
    assert break_even_hours(scenario) is None


def test_negative_values_are_rejected() -> None:
    scenario = CostScenario(purchase_cost=55_000, hourly_rate=-1, hours=100)
    with pytest.raises(ValueError):
        rental_cost(scenario)
