# Security policy

Do not open a public issue containing credentials, private IP addresses, billing information, access tokens, or exploitable details.

When a secret is exposed:

1. Revoke or rotate it immediately.
2. Remove it from active systems.
3. Audit logs and billing.
4. Purge it from Git history when required.
5. Document the incident without republishing the secret.
