# Code of Conduct

We expect respectful, technically rigorous, and honest collaboration.

Discuss evidence and designs rather than attacking people. Protect personal and security-sensitive information. Disclose referral relationships and conflicts of interest.

Harassment, threats, discrimination, deliberate misinformation, credential sharing, spam, and deceptive promotion are not accepted.
